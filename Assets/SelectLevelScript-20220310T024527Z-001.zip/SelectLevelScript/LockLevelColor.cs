using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LockLevelColor : MonoBehaviour
{
    // Start is called before the first frame update
    public Color LockColor;
}
