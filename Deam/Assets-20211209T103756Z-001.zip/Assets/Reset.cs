﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Reset : MonoBehaviour
{
    public GameObject buttonC11; 
    public GameObject buttonC12;
    public GameObject buttonC13;
    public GameObject buttonC21; 
    public GameObject TextbuttonC21; 
    public GameObject buttonC22;
    public GameObject TextbuttonC22; 
    public GameObject buttonC23;
    public GameObject TextbuttonC23; 
    public GameObject buttonC31; 
    public GameObject TextbuttonC31; 
    public GameObject buttonC32;
    public GameObject TextbuttonC32; 
    public GameObject buttonC33;
    public GameObject TextbuttonC33; 
    public GameObject ColorButton1;
    public GameObject AddOn;
    public GameObject ElementPick;
    public GameObject TimeDisplay;
    public GameObject DamageDisplay;
    public void Start(){
        ResetMassAndAtom();
    }
    public void Update(){
        if (AddOn.GetComponent<HPBoss>().Reset == true){
            ResetColor();
            ResetMassAndAtom();
            ResetDisplay();
            AddOn.GetComponent<HPBoss>().Reset = false;
        }
    }
    void ResetColor(){
        Color color = ColorButton1.GetComponent<ChangeButtonColorLock>().InactiveColor;
        buttonC11.GetComponent<Image>().color = color;
        buttonC11.SetActive(true);
        buttonC12.GetComponent<Image>().color = color;
        buttonC12.SetActive(true);
        buttonC13.GetComponent<Image>().color = color;
        buttonC13.SetActive(true);
        buttonC21.GetComponent<Image>().color = color;
        buttonC21.SetActive(true);
        buttonC22.GetComponent<Image>().color = color;
        buttonC22.SetActive(true);
        buttonC23.GetComponent<Image>().color = color;
        buttonC23.SetActive(true);
        buttonC31.GetComponent<Image>().color = color;
        buttonC31.SetActive(true);
        buttonC32.GetComponent<Image>().color = color;
        buttonC32.SetActive(true);
        buttonC33.GetComponent<Image>().color = color;
        buttonC33.SetActive(true);
        ElementPick.GetComponent<ElementPick>().Start = false;
    }
    void ResetMassAndAtom(){
        TextbuttonC21.GetComponent<Text>().text = "-";
        TextbuttonC22.GetComponent<Text>().text = "-";
        TextbuttonC23.GetComponent<Text>().text = "-";
        TextbuttonC31.GetComponent<Text>().text = "-";
        TextbuttonC32.GetComponent<Text>().text = "-";
        TextbuttonC33.GetComponent<Text>().text = "-";
    }
    void ResetDisplay(){
        TimeDisplay.GetComponent<Text>().text = "Next";
        DamageDisplay.GetComponent<Text>().text = "Result";
    }
}
