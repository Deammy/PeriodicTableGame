﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextLockButton : MonoBehaviour
{
    public GameObject Button1;
    public GameObject Button2;
    public GameObject Button3;
    public GameObject LockButton1;
    public GameObject LockButton2;
    public GameObject LockButton3;
    public GameObject Item1;
    public GameObject Item2;
    public GameObject Item3;
    public GameObject Item4;
    public GameObject LockItem1;
    public GameObject LockItem2;
    public GameObject LockItem3;
    public GameObject LockItem4;
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        LockButton1.GetComponent<Text>().text = Button1.GetComponent<Text>().text;
        LockButton2.GetComponent<Text>().text = Button2.GetComponent<Text>().text;
        LockButton3.GetComponent<Text>().text = Button3.GetComponent<Text>().text;
        LockItem1.GetComponent<Text>().text = Item1.GetComponent<Text>().text;
        LockItem2.GetComponent<Text>().text = Item2.GetComponent<Text>().text;
        LockItem3.GetComponent<Text>().text = Item3.GetComponent<Text>().text;
        LockItem4.GetComponent<Text>().text = Item4.GetComponent<Text>().text;
        
    }
}
