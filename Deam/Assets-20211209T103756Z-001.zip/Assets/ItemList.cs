﻿[System.Serializable]
public class ItemList{
    public int ExtraDamage;
    public int ExtraMove;
}