﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ElementPick : MonoBehaviour
{
    /////////////
    public List<Element> Elements;
    public int E1;
    
    public int E2;
    
    public int E3;
    
    public int M1;
    
    public int M2;
    
    public int M3;
    
    public int A1;
    
    public int A2;
    
    public int A3;
    public int S1;
    public int S2;
    public int S3;
    //////////////
    public Text R1Choice1;
    public Text R1Choice2;
    public Text R1Choice3;
    public Text R2Choice1;
    public Text R2Choice2;
    public Text R2Choice3;
    public Text R3Choice1;
    public Text R3Choice2;
    public Text R3Choice3;
    public int TimeCounting;
    public bool Start = false;

    ///////Generate Zone//////////
    private void Update()
    {
        if(Start == false){
            GenerateElementRole();
            Start = true;
        }
    }
    public void GenerateMassAndAtomNumberRoleC1()
    {
        GenerateMassNumberRoleC1();
        GenerateAtomNumberRoleC1();
        S1 = E1;
        TimeCounting = 1;
    }
    public void GenerateMassAndAtomNumberRoleC2()
    {
        GenerateMassNumberRoleC2();
        GenerateAtomNumberRoleC2();
        S1 = E2;
        TimeCounting = 1;
    }
    public void GenerateMassAndAtomNumberRoleC3()
    {
        GenerateMassNumberRoleC3();
        GenerateAtomNumberRoleC3();
        S1 = E3;
        TimeCounting = 1;
    }
    void GenerateElementRole()
    {
        E1 = Random.Range(0,Elements.Count);
        E2 = Random.Range(0,Elements.Count);
        E3 = Random.Range(0,Elements.Count);
        while (E1 == E2 || E1 == E3 || E2 == E3)
        {
            E2 = Random.Range(0,Elements.Count);
            E3 = Random.Range(0,Elements.Count); 
        }
        R1Choice1.text = Elements[E1].Elements;
        R1Choice2.text = Elements[E2].Elements;
        R1Choice3.text = Elements[E3].Elements;
    }
    void GenerateMassNumberRoleC1()
    {
        M1 = E1;
        M2 = Random.Range(0,Elements.Count);
        M3 = Random.Range(0,Elements.Count);
        while (M1 == M2 || M1 == M3 || M2 == M3)
        {
            M2 = Random.Range(0,Elements.Count);
            M3 = Random.Range(0,Elements.Count); 
        }
        R2Choice1.text = Elements[M1].MassNumber;
        R2Choice2.text = Elements[M2].MassNumber;
        R2Choice3.text = Elements[M3].MassNumber;
    }
    void GenerateMassNumberRoleC2()
    {
        M2 = E2;
        M1 = Random.Range(0,Elements.Count);
        M3 = Random.Range(0,Elements.Count);
        while (M1 == M2 || M1 == M3 || M2 == M3)
        {
            M1 = Random.Range(0,Elements.Count);
            M3 = Random.Range(0,Elements.Count); 
        }
        R2Choice1.text = Elements[M1].MassNumber;
        R2Choice2.text = Elements[M2].MassNumber;
        R2Choice3.text = Elements[M3].MassNumber;
    }
    void GenerateMassNumberRoleC3()
    {
        M3 = E3;
        M2 = Random.Range(0,Elements.Count);
        M1 = Random.Range(0,Elements.Count);
        while (M1 == M2 || M1 == M3 || M2 == M3)
        {
            M2 = Random.Range(0,Elements.Count);
            M1 = Random.Range(0,Elements.Count); 
        }
        R2Choice1.text = Elements[M1].MassNumber;
        R2Choice2.text = Elements[M2].MassNumber;
        R2Choice3.text = Elements[M3].MassNumber;
    }
    void GenerateAtomNumberRoleC1()
    {
        A1 = E1;
        A2 = Random.Range(0,Elements.Count);
        A3 = Random.Range(0,Elements.Count);
        while (A1 == A2 || A1 == A3 || A2 == A3)
        {
            A2 = Random.Range(0,Elements.Count);
            A3 = Random.Range(0,Elements.Count); 
        }
        R3Choice1.text = Elements[A1].AtomNumber;
        R3Choice2.text = Elements[A2].AtomNumber;
        R3Choice3.text = Elements[A3].AtomNumber;
    }
    void GenerateAtomNumberRoleC2()
    {
        A2 = E2;
        A1 = Random.Range(0,Elements.Count);
        A3 = Random.Range(0,Elements.Count);
        while (A1 == A2 || A1 == A3 || A2 == A3)
        {
            A1 = Random.Range(0,Elements.Count);
            A3 = Random.Range(0,Elements.Count); 
        }
        R3Choice1.text = Elements[A1].AtomNumber;
        R3Choice2.text = Elements[A2].AtomNumber;
        R3Choice3.text = Elements[A3].AtomNumber;
    }
    void GenerateAtomNumberRoleC3()
    {
        A3 = E3;
        A2 = Random.Range(0,Elements.Count);
        A1 = Random.Range(0,Elements.Count);
        while (A1 == A2 || A1 == A3 || A2 == A3)
        {
            A2 = Random.Range(0,Elements.Count);
            A1 = Random.Range(0,Elements.Count); 
        }
        R3Choice1.text = Elements[A1].AtomNumber;
        R3Choice2.text = Elements[A2].AtomNumber;
        R3Choice3.text = Elements[A3].AtomNumber;
    }
    ////Click Zone/////////
    public void R2C1Click()
    {
        S2 = M1 ;
    }
    public void R2C2Click()
    {
        S2 = M2 ;
    }
    public void R2C3Click()
    {
        S2 = M3 ;
    }
    public void R3C1Click()
    {
        S3 = A1 ;
    }
    public void R3C2Click()
    {
        S3 = A2 ;
    }
    public void R3C3Click()
    {
        S3 = A3 ;
    }
}
