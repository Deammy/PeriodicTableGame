﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class CountDownTiming : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject TimeDisplay;
    public int Seconds;
    public int SecondsLeft;
    public bool Check = false;
    public GameObject TimeCounting;
    public AudioSource source;
    public void Start()
    {
        TimeDisplay.GetComponent<Text>().text = "Ready";
    }

    void Update()
    {
        if(TimeCounting.GetComponent<ElementPick>().TimeCounting == 1)
        {
            if(SecondsLeft >= 0 && Check == false)
            {
                StartCoroutine(CountDown());
            }
        }
    }
    IEnumerator CountDown()
    {
        Check = true;
        TimeDisplay.GetComponent<Text>().text = ""+ SecondsLeft;
        if(SecondsLeft>0){
            source.Play();
        }
        yield return new WaitForSeconds(1);
        SecondsLeft -= 1;

        Check = false;
    }
    public void SafeTiming()
    {
        SecondsLeft = Seconds;
    }
}
