﻿[System.Serializable]
public class Element{
    public string Elements;
    public string MassNumber;
    public string AtomNumber;
}