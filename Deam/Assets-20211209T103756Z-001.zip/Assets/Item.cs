﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public GameObject ItemButton0;
    public GameObject ItemButton1;
    public GameObject ItemButton2;
    public GameObject ItemButton3;
    public GameObject ItemButton4;
    public int Extra;
    public int ExtraDamage;
    public int ExtraMove;
    public List<ItemList> ExtraList;
    public HPBoss Calculate;
    public bool Confirm = false;
    public void Item0(){
        Extra = ItemButton0.GetComponent<ItemNumbers>().ItemNumber;
        ExtraDamage = ExtraList[Extra].ExtraDamage;
        ExtraMove = ExtraList[Extra].ExtraMove;
        Confirm = true;
    }
    public void Item1(){
        Extra = ItemButton1.GetComponent<ItemNumbers>().ItemNumber;
        ExtraDamage = ExtraList[Extra].ExtraDamage;
        ExtraMove = ExtraList[Extra].ExtraMove;
        ItemButton1.SetActive(false);
        Confirm = true;
    }
    public void Item2(){
        Extra = ItemButton2.GetComponent<ItemNumbers>().ItemNumber;
        ExtraDamage = ExtraList[Extra].ExtraDamage;
        ExtraMove = ExtraList[Extra].ExtraMove;
        ItemButton2.SetActive(false);
        Confirm = true;
    }
    public void Item3(){
        Extra = ItemButton3.GetComponent<ItemNumbers>().ItemNumber;
        ExtraDamage = ExtraList[Extra].ExtraDamage;
        ExtraMove = ExtraList[Extra].ExtraMove;
        ItemButton3.SetActive(false);
        Confirm = true;
    }
    public void Item4(){
        Extra = ItemButton4.GetComponent<ItemNumbers>().ItemNumber;
        ExtraDamage = ExtraList[Extra].ExtraDamage;
        ExtraMove = ExtraList[Extra].ExtraMove;
        ItemButton4.SetActive(false);
        Confirm = true;
    }
}
