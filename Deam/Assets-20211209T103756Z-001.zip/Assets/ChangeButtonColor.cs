﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeButtonColor : MonoBehaviour
{
    public GameObject button1; 
    public GameObject button2;
    public GameObject button3;
    public Color ActiveColor;
    public Color InactiveColor;
    // Start is called before the first frame update
    public void Start(){
        button1.GetComponent<Image>().color = InactiveColor;
        button2.GetComponent<Image>().color = InactiveColor;
        button3.GetComponent<Image>().color = InactiveColor;
    }
    public void C1Click(){
        button1.GetComponent<Image>().color = ActiveColor;
        button2.GetComponent<Image>().color = InactiveColor;
        button3.GetComponent<Image>().color = InactiveColor;
    }
    public void C2Click(){
        button1.GetComponent<Image>().color = InactiveColor;
        button2.GetComponent<Image>().color = ActiveColor;
        button3.GetComponent<Image>().color = InactiveColor;
    }
    public void C3Click(){
        button1.GetComponent<Image>().color = InactiveColor;
        button2.GetComponent<Image>().color = InactiveColor;
        button3.GetComponent<Image>().color = ActiveColor;
    }
}
