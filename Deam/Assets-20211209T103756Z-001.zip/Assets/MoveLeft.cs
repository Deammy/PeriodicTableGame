﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MoveLeft : MonoBehaviour
{
    public int MoveStart;
    public GameObject MoveDisplay;
    public GameObject ExtraMove;
    public void Start(){
        MoveDisplay.GetComponent<Text>().text = "" + MoveStart;
    }
    public void MoveLefting(){
        MoveStart = MoveStart - 1;
        MoveStart = MoveStart + ExtraMove.GetComponent<Item>().ExtraMove;
        MoveDisplay.GetComponent<Text>().text = "" + MoveStart;
    }
}
