﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPBoss : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject Blood;
    public GameObject ElementPick;
    public int BossBlood;
    public int DMR;
    public GameObject TimeDisplay;
    public GameObject DamageDisplay;
    public string DamageRate;
    public bool Break = false;
    public MoveLeft Move;
    public GameObject ExtraDamage;
    public bool Reset = false;
    public AudioSource source;
    void Start()
    {
        Blood.GetComponent<Text>().text = "" + BossBlood;
    }
    void Update()
    {
        if(TimeDisplay.GetComponent<Text>().text == "0"){
            TimeDisplay.GetComponent<Text>().text = "Stop";
            source.Play();
        }
        if(Break == false && ExtraDamage.GetComponent<Item>().Confirm == true){
            StartCoroutine(CalculateDamage());
        }
    }

    // Update is called once per frame
    public IEnumerator CalculateDamage()
    {
        Break = true;
        int S1 = ElementPick.GetComponent<ElementPick>().S1;
        int S2 = ElementPick.GetComponent<ElementPick>().S2;
        int S3 = ElementPick.GetComponent<ElementPick>().S3;
        if (S2 != S3){
            if(S1 == S3 || S1 == S2){
                DamageRate = "10";
                DMR = 10;
            }
            else{
                DamageRate = "0";
                DMR = 0;
            }
        } 
        if (S1 == S2 && S1 == S3){
            DamageRate = "20";
            DMR = 20;
        }
        DMR = DMR + ExtraDamage.GetComponent<Item>().ExtraDamage;
        yield return new WaitForSeconds(1);
        DamageDisplay.GetComponent<Text>().text = "" + DMR;
        yield return new WaitForSeconds(1);
        BossBlood = BossBlood - DMR;
        Blood.GetComponent<Text>().text = "" + BossBlood;
        Move.MoveLefting();
        yield return new WaitForSeconds(1);
        Reset = true;
        Break = false;
        ExtraDamage.GetComponent<Item>().Confirm = false;
    }
}
